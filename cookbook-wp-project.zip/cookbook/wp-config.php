<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cookbook' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'rF=S]h9ooZ|@7jFevRzvIx=*^eI81*M}im{pN5{`;~NcCMMq7%`G]PzEYJjF[uQJ' );
define( 'SECURE_AUTH_KEY',  'BS20Y35lkgyd=IPT09,Z2 ]id>R8Y=q!D%F_DoMCZ?m`mr66qdY;ARf!y](kb5`S' );
define( 'LOGGED_IN_KEY',    'bW;/,!pkp7mH,J]lA>5q{<fnjv^+r]P0<v CX}?;uuIr# evY>Y/g+l1q_ciw(Hp' );
define( 'NONCE_KEY',        'wL8!6z1Eu|M;CEP9TQY_JJ$%{<#QS<Xf#AiR`!UgpjTYLrmSk0 2&LJA>y})Bo`D' );
define( 'AUTH_SALT',        'Bh;[czow7Y!/9_!hon}! )RtUqO_g~v<lzQn/pK* J]~&;`huU:b8aJ28}3HvLvv' );
define( 'SECURE_AUTH_SALT', '`4c^.MV@aGRnK@-1I7D@iSip|Yf^f=*6a)FQ)!))I|Tg*ODAG-ruQ_ @e4BP%N ?' );
define( 'LOGGED_IN_SALT',   '%G@AN8O|<r50!0R$Q*ZDST+i%]_G,FPq_~ ~$yoT9hFW4ol}xg(!h?X!-,;SxFkX' );
define( 'NONCE_SALT',       'k)ig0HsM-cQ+E{ah9rW4YYpQD/iGN/K RRXG4 uHhluQN>Z:|?JSo+VA|]m|HWk4' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_cb_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
