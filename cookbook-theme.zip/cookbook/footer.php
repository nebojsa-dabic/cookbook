<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Cookbook
 */

?>

</div><!-- #content -->
	<footer class="site-footer">
		<div class="container">
			<div class="row">

				<div class="footer-column col-lg-4 footer-widget-left">
					<?php dynamic_sidebar( 'footer-1' ); ?>
				</div>
				<div class="footer-column col-lg-4 footer-widget-center">
					<?php dynamic_sidebar( 'footer-2' ); ?>
				</div>
				<div class="footer-column col-lg-4 footer-widget-right">
					<?php dynamic_sidebar( 'footer-3' ); ?>
				</div>	

			</div>
			<div class="scroll-to-top">
				<i class="fas fa-chevron-up"></i>
			</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>