WP development assignment - Cookbook1.

1. Create a custom theme
2. Register custom post type "recipe"
3. Every visitor is allowed to submit a recipe
3. Recipes should have a title, description, and photo(photo is not required)
4. Recipes are not public until admin approves them
5. Add "New recipes" custom menu to admin sidebar where admin can approve a recipe (show them in a table)
6. Create home page with approved recipes, single recipe page, and "submit a recipe" page
7. Create simple header with navigation

Tips:
Design is not important, make it simple, but layout should be responsive.
JavaScript libraries are allowed, Bootstrap (or similar css framework) is allowed, SCSS and LESS are allowed.

Bonus:
1. Use AJAX for recipe submission
2. Add "Theme options" custom menu to admin sidebar where he can upload an image that will be shown as default if no image is uploaded for a recipe
3. Pagination on home page

Once you have task completed push your theme to publicly available git repository (GitHub or similar) and send us repository url.
Exported database should be included, every important info (admin login credentials or similar should be in README file)