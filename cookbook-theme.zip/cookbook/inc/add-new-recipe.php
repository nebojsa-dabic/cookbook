<?php

// Enable Ajax
add_action('wp_ajax_nopriv_add_new_recipe', 'add_new_recipe');
add_action('wp_ajax_add_new_recipe', 'add_new_recipe');

// Handle ajax request
function add_new_recipe(){

	/*
	* Create recipe custom post type with "pending" status
	*/
    $new_post = array(
        'post_title' => $_POST['title'],
        'post_content' => $_POST['description'],
        'post_status' => 'pending',
        'post_date' => date('Y-m-d H:i:s'),
        'post_type' => 'recipe',
        'post_category' => array(0)
    );

	// Return the post id
	$post_id = wp_insert_post($new_post);
	

	/*
	* Upload image
	*/
	$wordpress_upload_dir = wp_upload_dir();
	$image = $_FILES['image'];
	$new_file_path = $wordpress_upload_dir['path'] . '/' . $image['name'];
	$new_file_mime = mime_content_type( $image['tmp_name'] );
	
	// number of tries when the file with the same name is already exists
	$i = 1;
	while( file_exists( $new_file_path ) ) {
		$i++;
		$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $image['name'];
	}
	
	// looks like everything is OK
	if( move_uploaded_file( $image['tmp_name'], $new_file_path ) ) {
	
		$image_id = wp_insert_attachment( array(
			'guid'           => $new_file_path, 
			'post_mime_type' => $new_file_mime,
			'post_title'     => preg_replace( '/\.[^.]+$/', '', $image['name'] ),
			'post_content'   => '',
			'post_status'    => 'inherit'
		), $new_file_path );
	
		// wp_generate_attachment_metadata() won't work if you do not include this file
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
	
		// Generate and save the attachment metas into the database
		wp_update_attachment_metadata( $image_id, wp_generate_attachment_metadata( $image_id, $new_file_path ) );

		// Attach uploaded image with newly created recipe post
		set_post_thumbnail( $post_id, $image_id ); // set the ID of your thumbnail to be the featured image of your newly created post.
	}


	// Must die at the end because it will attach number 1 to JS Ajax response
	die();
}


?>