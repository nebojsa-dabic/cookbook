<?php

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
require get_template_directory() . '/inc/widgets/widget-register-area.php';

/**
 * Load Parent Widget class
 * Here will be all mutual properties and methods
 */
require get_template_directory() . '/inc/widgets/widget_parent.class.php';


foreach (glob(get_template_directory() . "/inc/widgets/widget/*.php") as $filename) {
    require_once $filename;
}