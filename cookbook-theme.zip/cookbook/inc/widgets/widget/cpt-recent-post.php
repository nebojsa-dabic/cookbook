<?php

// Register and load the widget
function load_widget_cpt_recent() {
    register_widget( 'widget_cpt_recent' );
}
add_action( 'widgets_init', 'load_widget_cpt_recent' );
 
// Creating the widget 
class widget_cpt_recent extends Widget_Parent {

	public $layout_types;
	
	public function __construct() {
		parent::__construct(
			// Base ID of your widget
			'widget_cpt_recent_post', 
			
			// Widget name will appear in UI
			__('Recent Custom Post Type', 'cookbook'), 
			
			// Widget description
			array( 'description' => __( 'Your site’s most recent Posts from Custom Post Type.', 'cookbook' ), ) 
		);
	}
	
	/**
	 * Creating widget front-end
	 */ 
	public function widget( $args, $instance ) {

		echo "<div class=\"recent-post-wrap\">";
			echo "<section class=\"widget\">";
				// Title
				if ( ! empty( $instance['title'] ) ) {
					echo "<h2 class=\"widget-title\">". $instance['title'] ."</h2>";
				}

				// Loop through post items
				$loop = new WP_Query( array(
					'post_type' => $instance['post_type'],
					'posts_per_page' => $instance['num_posts'],
					// 'offset' => 0,
					'paged' => get_query_var('page'),
					'tax_query' => $this->tax_query($instance['post_type'], $instance['category'])
				) );
				$index = 0;
				while ( $loop->have_posts() ) : $loop->the_post();
					$index++;
					?>
					<div class="recent-post-item-wrap">
						<a class="recent-post-item child-<?php echo $index; ?>" href="<?php echo get_permalink(); ?>">
							<div class="recent-post-image">
								<?php custom_post_image(); ?>
							</div>
							<div class="recent-post-content">
								<div class="recent-post-title">
									<?php echo get_the_title(); ?>
								</div>
								<div class="recent-post-description">
									<?php echo stripslashes( substr(wp_filter_nohtml_kses( get_the_content() ), 0, 300) ); ?>
								</div>
								<div class="recent-posts-meta">
									<span class="recent-post-date">
										<?php echo get_the_date(); ?>
									</span>
								</div>
							</div>
						</a>
					</div>
					<?php
				endwhile;
				wp_reset_query();
				?>
			</select>

			<div class="recent-post-pagination">
			<?php
			if($instance[ 'pagination' ] == 1) {
				numeric_posts_nav($loop); 
			}
			?>
			</div>
		</div>
		<?php
	}
			
	/**
	 * Widget Admin Backend
	 */ 
	public function form( $instance ) {
		if ( !isset( $instance[ 'num_posts' ] ) ) {
			$instance[ 'num_posts' ] = 5;
		}
		if ( !isset( $instance[ 'post_type' ] ) ) {
			$instance[ 'post_type' ] = 'post';
		}
		$pagination_checked = ($instance[ 'pagination' ] == 1) ? 'checked' : '';

		// Widget admin form
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php _e( 'Title:' ); ?>
			</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $instance[ 'title' ] ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'num_posts' ); ?>">
				<?php _e( 'Number of posts to show:' ); ?>
			</label>
			<input class="tiny-text" id="<?php echo $this->get_field_id( 'num_posts' ); ?>" name="<?php echo $this->get_field_name( 'num_posts' ); ?>" type="number" step="1" min="1" value="<?php echo $instance[ 'num_posts' ]; ?>" size="3">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'post_type' ); ?>">
				<?php _e( 'Select post type:' ); ?>
			</label>
			<select id="<?php echo $this->get_field_id( 'post_type' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'post_type' ); ?>" >
				<?php
				$post_types = $this->post_types();
				foreach ( $post_types as $post_type ) {
					$selected = ($instance[ 'post_type' ] == $post_type) ? 'selected' : '';
					echo "<option {$selected} value=\"{$post_type}\">". ucfirst($post_type) ."</option>";
				}
				?>
			</select>
		</p>
		<p>
			<input class="widefat" id="<?php echo $this->get_field_id( 'pagination' ); ?>" name="<?php echo $this->get_field_name( 'pagination' ); ?>" type="checkbox" value="1" <?php echo $pagination_checked; ?> />
			<label for="<?php echo $this->get_field_id( 'pagination' ); ?>">
				<?php _e( 'Use pagination' ); ?>
			</label> 
		</p>

		<script>
			$ = jQuery.noConflict();
			$(document).ready(function(){

				$(document).off("change", "#<?php echo $this->get_field_id( 'post_type' ); ?>").on("change", "#<?php echo $this->get_field_id( 'post_type' ); ?>", function(){
					$(this).closest("form").find("#<?php echo $this->get_field_id( 'savewidget' ); ?>").click();
				});

				for(var i = 0; i < $(".pagination").length; i++) {
					var selectElement = "."+$(".pagination").eq(i).attr("id")
					
					if( $(".pagination").eq(i).is(":checked") ) {
						$(selectElement).show();
					}

				}
			})
		</script>
		<?php
	}
		
	/**
	 * Updating widget replacing old instances with new
	 */ 
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['num_posts'] = ( ! empty( $new_instance['num_posts'] ) ) ? strip_tags( $new_instance['num_posts'] ) : '5';
		$instance['post_type'] = ( ! empty( $new_instance['post_type'] ) ) ? strip_tags( $new_instance['post_type'] ) : 'post';
		$instance['category'] = ( ! empty( $new_instance['category'] ) ) ? strip_tags( $new_instance['category'] ) : '';
		$instance['pagination'] = ( ! empty( $new_instance['pagination'] ) ) ? strip_tags( $new_instance['pagination'] ) : '';


		return $instance;
	}
}