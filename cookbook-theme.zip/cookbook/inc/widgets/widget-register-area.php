<?php

$widget_register_area = Array(
	// // Post after content
	Array("id" => "home-page", "name" => "Home page content"),
	// Standard footer
	Array("id" => "footer-1", "name" => "Footer 1"),
	Array("id" => "footer-2", "name" => "Footer 2"),
	Array("id" => "footer-3", "name" => "Footer 3"),
);

/**
 * Define multiple widget areas
 */
function kommando_widgets_init($widget_register_area) {
	foreach($widget_register_area as $widget) {
		register_sidebar( array(
			'name'          => esc_html__( $widget['name'], THEME_NAME ),
			'id'            => $widget['id'],
			'description'   => esc_html__( 'Add widgets here.', THEME_NAME ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );
	}
}

add_action('widgets_init', 
			function() use ( $widget_register_area ) {
			kommando_widgets_init( $widget_register_area ); });