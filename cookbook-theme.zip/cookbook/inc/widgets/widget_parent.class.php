<?php

class Widget_Parent extends WP_Widget {

    // Get all post types
	protected function post_types() {
		$post_types = Array("post"); // "page"
		$args = array(
			'public'   => true,
			'_builtin' => false
		);
		$output = 'names';
		$operator = 'and';
		return $post_types += get_post_types( $args, $output, $operator ); 
    }


    // Display post category
	protected function get_category($id) { // , $post_type
		// TODO: hardcoded custom post type taonomy category name 'news-category'
		$category = get_the_terms($id, 'news-category');
		if( empty($category) ) {
			$category = get_the_category();
		}

		return $category;
    }
    

    // Get post type taxonomy
	protected function get_taxonomy($post_type) {
		$taxonomy = "category";
		if($post_type != "post") {
			$taxonomy = $post_type ."-category";
		}

		return $taxonomy;
	}

	// Get posts by type
	protected function tax_query($post_type, $category) {
		if($category == 0) {
			return "";
		}
		return array(
			array(
				'taxonomy' => $this->get_taxonomy($post_type),
				'field' => 'term_id',
				'terms' => $category
			)
		);
    }
    

}