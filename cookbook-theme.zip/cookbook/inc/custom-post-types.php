<?php
function create_posttype() {
    register_post_type( 'Recipe',
        // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Recipes' ),
                'singular_name' => __( 'Recipe' )
            ),
            'public' => true,
            'has_archive' => true,
            'show_in_rest' => true,
            'exclude_from_search' => false,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'taxonomies'  => array( 'recipe-category' ),
            'rewrite' => array(
                'slug' => 'recipe',
                'with_front' => false
            ),
        )
    );
}

add_action( 'init', 'create_posttype' );

// Register custom taxonomy for CPT 
add_action( 'init', 'custom_taxonomy' );

function custom_taxonomy(){
register_taxonomy( 'recipe-category', 'recipe', array(
'hierarchical'  => true,
'label' => 'Categories',
        'labels'        => array(
            'name'              => _x( 'Categories', 'taxonomy general name' ),
            'singular_name'     => _x( 'Category', 'taxonomy singular name' ),
            'search_items'      =>  __( 'Search Categories' ),
            'all_items'         => __( 'All Categories' ),
            'parent_item'       => __( 'Parent Category' ),
            'parent_item_colon' => __( 'Parent Category:' ),
            'edit_item'         => __( 'Edit Category' ),
            'update_item'       => __( 'Update Category' ),
            'add_new_item'      => __( 'Add New Category' ),
            'new_item_name'     => __( 'New Category Name' ),
            'menu_name'         => __( 'Category' ),
        ),
        'show_ui'       => true,
        'query_var'     => true,
     ) );
}
