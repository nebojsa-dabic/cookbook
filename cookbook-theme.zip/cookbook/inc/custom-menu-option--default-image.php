<?php

add_action( 'admin_menu', 'register_media_selector_settings_page' );

function register_media_selector_settings_page() {
	// add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
	add_menu_page( 'Theme options', 'Theme options', 'manage_options', 'default_image', 'default_image_options_page');
}

function default_image_options_page() {

	// Save attachment ID
	if ( isset( $_POST['submit_image_selector'] ) && isset( $_POST['image_attachment_id'] ) ) :
		update_option( 'media_selector_attachment_id', absint( $_POST['image_attachment_id'] ) );
	endif;

	$image = wp_get_attachment_url( get_option( 'media_selector_attachment_id' ) );
	$display = "block";
	if( empty($image) ) {
		$display = "none";
	}

	wp_enqueue_media();

	?>
	<div>
		<h1>Theme options</h1>
		<h3>Here you can set default image for recipes if user is not uload ther image.</h3>

		<form method='post'>
			<div class='image-preview-wrapper' style="display: <?php echo $display; ?>">
				<img id='image-preview' src='<?php echo $image; ?>' height='100'>
				<br><br>
				<input type="reset" value="Delete Image" class="button delete-image" style="color: red;">
				<br><br>
			</div>
			<input type='hidden' name='image_attachment_id' id='image_attachment_id' value='<?php echo get_option( 'media_selector_attachment_id' ); ?>'>
			<input id="upload_image_button" type="button" class="button" value="<?php _e( 'Upload image' ); ?>" />

			<br><br>
			<input type="submit" name="submit_image_selector" value="Save" class="button-primary">
		</form>
	</div>
	<?php



	$my_saved_attachment_post_id = get_option( 'media_selector_attachment_id', 0 );
	$my_saved_attachment_post_id = ( empty($my_saved_attachment_post_id) ) ? "0" : $my_saved_attachment_post_id;

	?><script type='text/javascript'>

		jQuery( document ).ready( function( $ ) {

			// Uploading files
			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this

			jQuery('#upload_image_button').on('click', function( event ){

				event.preventDefault();

				// If the media frame already exists, reopen it.
				if ( file_frame ) {
					// Set the post ID to what we want
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					// Open frame
					file_frame.open();
					return;
				} else {
					// Set the wp.media post id so the uploader grabs the ID we want when initialised
					wp.media.model.settings.post.id = set_to_post_id;
				}

				// Create the media frame.
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	// Set to true to allow multiple files to be selected
				});

				// When an image is selected, run a callback.
				file_frame.on( 'select', function() {
					// We set multiple to false so only get one image from the uploader
					attachment = file_frame.state().get('selection').first().toJSON();

					// Do something with attachment.id and/or attachment.url here
					$( '.image-preview-wrapper' ).show();
					$( '#image-preview' ).attr( 'src', attachment.url ).css( 'width', 'auto' );
					$( '#image_attachment_id' ).val( attachment.id );

					// Restore the main post ID
					wp.media.model.settings.post.id = wp_media_post_id;
				});

					// Finally, open the modal
					file_frame.open();
			});

			// Restore the main ID when the add media button is pressed
			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});

			// Delete image
			jQuery( '.delete-image' ).on( 'click', function() {
				$( '.image-preview-wrapper' ).hide();
				$( '#image-preview' ).attr( 'src',"" );
				$( '#image_attachment_id' ).val( 0 );
			});
		});

	</script><?php

}

