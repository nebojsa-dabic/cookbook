<?php

if( isset($_POST['post_id']) ) {
	wp_update_post(array(
		'ID'    =>  $_POST['post_id'],
		'post_status'   =>  'publish'
	));
}

// Create options
function pending_recipes_register_settings() {
	add_option( 'pending_recipes_option_name', 'This is my option value.');
	register_setting( 'pending_recipes_options_group', 'pending_recipes_option_link_from', 'pending_recipes_callback' );
}
add_action( 'admin_init', 'pending_recipes_register_settings' );

// Add option to left menu as Settings submenu
function pending_recipes_register_options_page() {
	$notification_count = get_pending_recipes_count();
	add_menu_page(
		'New pending recipes',
		$notification_count ? sprintf('New recipes <span class="awaiting-mod">%d</span>', $notification_count) : 'New recipes',
		'manage_options',
		'pending_recipes',
		'pending_recipes_options_page'
	);
}
add_action('admin_menu', 'pending_recipes_register_options_page');


// Admin frontend part
function pending_recipes_options_page()
{
?>
	<style>
		.recipe-table {
			width: 100%;
			margin: 40px 0;
		}
		th {
			text-align: center;
			border: 1px solid #9e9d9d;
			border-radius: 4px;
		}
		td {
			border: 1px solid #dfdfdf;
			border-radius: 4px;
			padding: 5px 20px;
			font-size: 18px;
		}
		td p {
			font-size: 18px;
		}
		img {
			max-width: 150px; 
			width: auto;
			max-height: 100px; 
			height: auto;
		}
		.field-img {
			width: 200px;
			text-align: center;
		}
		.field-title {
			width: 300px;
		}
		.no-pending {
			font-size: 30px;
			color: #777;
		}
	</style>

	<script>
		$ = jQuery.noConflict();
		$(document).ready(function(){
			// Minus button
			$(document).on("click", ".pending_recipes-button-minus", function(e){
				$(this).closest(".pending_recipes-row").remove();
			});
		});
	</script>

	<div>
	<?php screen_icon(); ?>
	<h1>New pending recipes</h1>
	<h3>Here you can approve users recipes. <?php echo get_pending_recipes()->found_posts; ?></h3>

	<?php if( get_pending_recipes_count() > 0 ) : ?>

	<table class="recipe-table">
		<tr>
			<th class="field-img"><h3>Recipe image</h3></th>
			<th class="field-title"><h3>Recipe title</h3></th>
			<th class="field"><h3>Recipe description</h3></th>
			<th class="field-action">Approve</th>
		</tr>
		<?php
		$loop = get_pending_recipes();
		while ( $loop->have_posts() ) : $loop->the_post();
		?>
		<tr>
			<td class="field-img"><?php custom_post_image(); ?></td>
			<td class="field-title"><?php the_title(); ?></td>
			<td class="field"><?php the_content(); ?></td>
			<td class="field-action">
				<form method="post" action="" >
					<input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>">
					<input type="hidden" name="action" value="update_recipe">
					<input type="submit" name="" value="Publish" class="button-primary">
				</form>
			</td>
		</tr>
		<?php
		endwhile;
		wp_reset_query();
		?>
	</table>
	<?php
	else :
	?>
	<h3 class="no-pending">There is no pending recepies</h3>
	<?php
	endif;

	?>
	</div>
<?php
}

// Do pending_recipes for inserted links
function pending_recipes_links() {
	$url_slug = trim($_SERVER['REQUEST_URI'], "/");
	$url_from = get_option('pending_recipes_option_link_from');
	$url_to = get_option('pending_recipes_option_link_to');

	if( is_array($url_from) ) {
		if( in_array($url_slug, $url_from) ) {
			$slug_index = array_search($url_slug, $url_from);
			// 307 - Temporary pending_recipes
			wp_pending_recipes( $url_to[$slug_index], 307 );
			die;
		}
	}
}
add_action('init', 'pending_recipes_links');