$ = jQuery.noConflict();

$(document).ready(function(){
	
	// Show Scroll to top if page is scrolled
	$(document).on('scroll', function(){
		var position = $(document).scrollTop();
		if(position > 200) {
			$(".scroll-to-top").addClass('bck-on');
		} else {
			$(".scroll-to-top").removeClass('bck-on');
		}
	 });


	// Scroll to top
	$(document).on("click", ".scroll-to-top", function(){
		$('html,body').animate({ scrollTop: 0 }, 'slow');
	});

	
	// Open mobile menu
	$(document).on("click", ".open-mobile-menu", function(){
		$(".site-navigation").slideToggle();
	});

	// Submit recipe button click
	$(document).on("click", ".submit-recipe", function(event){
		// disable default form submit
		event.preventDefault();

		// Stop if form is not valid
		if( ! validateFields(['title', 'description']) ) {
			return false;
		}

		// Append image to post request
		var file_data = $('#image').prop('files')[0];
		var form_data = new FormData();
		form_data.append('image', file_data);
		form_data.append('action', 'add_new_recipe');
		form_data.append('title', $("#title").val());
		form_data.append('description', $("#description").val());

		$.ajax({
			url: "/wp-admin/admin-ajax.php",
			type: 'post',
			contentType: false,
			processData: false,
			data: form_data,
		})
		.fail(function(r,status,jqXHR) {
			// console.log('failed');
			$(".form-block").append("<p class='error-message'>There has been an error. Please try again.</p>");
		})
		.done(function(r,status,jqXHR) {
			// console.log('success');
			// console.log(r);
			$(".form-block").append("<p class='success-message'>Recipe is submited successfully. Will be displayed after admin approves it.</p>");
		});
	});
	
});


/*
* Custom form validation
*/
function validateFields(fields) {
	// Default validation is true
	var valid = true;

	// Remove all old error massages
	$(".error-message, .success-message").remove();
	// Also remove all error classes for form elements
	$(".form-element").removeClass("input-error");

	// Check all given elements
	for(i in fields) {
		var formElement = $("#"+fields[i]);

		if( formElement.val() == "") {
			// Add error class to form field
			formElement.addClass("input-error")

			// Append error message after input field
			formElement.after("<p class='error-message'>Field is required</p>");

			// Set validation to false
			valid = false;
		}
	}

	return valid;
}

// End Custom scripts
