<?php
/*Template Name: Add new recipe */
get_header();
?>
<div id="page-content" class="add-new-recipe-page">

<div class="container">
	<form method="post" action="" class="recipe-form row" enctype="multipart/form-data">
		<div class="col-lg-8 offset-lg-2 form-block">
			<h1>Add new recipe</h1>
			<input type="text" name="title" id="title" class="form-element" placeholder="Recipe title (required)">
			<textarea name="description" id="description" class="form-element" placeholder="Recipe description (required)"></textarea>
			<input type="file" name="image" id="image">
			<br>
			<button class="submit-recipe">Add new recipe</button>
			<br>
		</div>
	</form>
</div>

</div>
<?php get_footer(); ?>