<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Cookbook
 */

get_header();
?>

	<div id="primary" class="post-page container">
		<main id="page-content" class="row">
			<div class="col-lg-8 offset-lg-2 page-404">
			404
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
