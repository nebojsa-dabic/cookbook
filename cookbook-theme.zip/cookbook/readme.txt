=== Cookbook ===

Contributors: automattic
Tags: custom-theme, job-task, custom-post-type

Requires at least: 4.5
Tested up to: 4.8
Stable tag: 1.0.0
License: GNU General Public License
License URI: LICENSE

A starter theme called Cookbook.

== Description ==

Cookbook theme with custom posty type "Recipes"

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Cookbook includes support for Infinite Scroll in Jetpack.

== Changelog ==

= 1.0 - Jan 25 2020 =
* Initial release

== Credits ==

* No credits for now
