<?php
/**
 * Cookbook functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Cookbook
 */

define("THEME_NAME", "cookbook");


if ( ! function_exists( 'cookbook_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function cookbook_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Cookbook, use a find and replace
		 * to change 'cookbook' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'cookbook', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'cookbook' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'cookbook_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'cookbook_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function cookbook_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'cookbook_content_width', 640 );
}
add_action( 'after_setup_theme', 'cookbook_content_width', 0 );


/**
 * Enqueue scripts and styles.
 */
function cookbook_scripts() {
	// Custom theme style
	wp_enqueue_style( 'cookbook-style', get_template_directory_uri() . '/layouts/style.min.css' );

	// Custom theme JavaScript code
	wp_enqueue_script( 'cookbook-masterscript', get_template_directory_uri() . '/js/masterscript.js', array("jquery"), '20151215', true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'cookbook_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

 /**
 * Activate new jQuery
 */
function replace_core_jquery_version() {
	wp_deregister_script( 'jquery-core' );
    wp_register_script( 'jquery-core', "/wp-content/themes/cookbook/js/lib/jquery/jquery-3.4.1.min.js", array(), '3.4.1' );
    wp_deregister_script( 'jquery-migrate' );
    wp_register_script( 'jquery-migrate', "/wp-content/themes/cookbook/js/lib/jquery/jquery-migrate-3.0.0.min.js", array(), '3.0.0' );
}
add_action( 'wp_enqueue_scripts', 'replace_core_jquery_version' );


/**
 * Custom image set for featured image for custom post type
 */
function custom_post_image() {
	if( has_post_thumbnail() ) {
		the_post_thumbnail();
	}
	else {
		$image = wp_get_attachment_url( get_option( 'media_selector_attachment_id' ) );
		echo '<img src="'. $image .'" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">';
	}
}


/**
 * Get pending recipes
 * 
 * Get total pending recipes
 */
function get_pending_recipes() {
	$query = array(
		'post_type' => 'recipe',
		'posts_per_page' => -1,
		'post_status' => array('pending') 
	);
	return new WP_Query($query);
}
function get_pending_recipes_count() {
	return get_pending_recipes()->found_posts;
}


/**
 * Disable gutenberg
 */
add_filter( 'use_block_editor_for_post', '__return_false' );


/**
 * Custom Post Type
 */
require get_template_directory() . '/inc/custom-post-types.php';


/**
 * Numeric navigation
 */
require get_template_directory() . '/inc/numeric-pagination.php';



/**
 * Register widget area.
 */
require get_template_directory() . '/inc/widgets/widgets-loader.php';



/**
 * Add new recipe.
 */
require get_template_directory() . '/inc/add-new-recipe.php';


/**
 * WP Option for left menu
 * 
 * Set default image
 * Approve pending recipes
 */
require get_template_directory() . '/inc/custom-menu-option--default-image.php';
require get_template_directory() . '/inc/custom-menu-option--pending-recipes.php';




// // Enable Ajax
// add_action('admin_post_nopriv_update_recipe', 'aaa');

// function aaa() {
// 	echo $_POST['post_id'];
// 	die("Dsadas");
	
// 	wp_update_post(array(
// 		'ID'    =>  $$_POST['post_id'],
// 		'post_status'   =>  'published'
// 	));
// }