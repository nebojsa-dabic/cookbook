<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Cookbook
 */

get_header();
?>

	<div id="primary" class="post-page container">
		<main id="page-content" class="row">
			<div class="col-lg-8 offset-lg-2">

			<?php
			while ( have_posts() ) : the_post();
			?>

			<header class="entry-header">
				<h1 class="entry-title"><?php the_title(); ?></h1>
				<div class="entry-meta">Posted on: <?php echo get_the_date(); ?></div>
			</header>
			<div class="entry-content">
				<div class="post-image"><?php custom_post_image(); ?></div>
				<div class="post-content"><?php the_content(); ?></div>
			</div>

			<?php
			endwhile; // End of the loop.
			?>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
